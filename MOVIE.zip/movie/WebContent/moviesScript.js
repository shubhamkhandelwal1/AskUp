var app=angular.module("movieApp" , ["ngRoute"]);


app.config([ '$routeProvider', '$locationProvider',
    function($routeProvider, $locationProvider) {
        $routeProvider.when('/pages/index.html', {
        
            templateUrl : 'pages/index.html'/*,
            controller : 'apiCtrll'*/
        })
        
        $routeProvider.when('/pages/search.html', {
            templateUrl : 'pages/search.html'
           /* controller : 'apiCtrll'*/
            
        }).otherwise({
        	url : "/" ,
            redirectTo : 'pages/index.html'
        });
        
    }
]);


app.controller("apiCtrll",function($scope,$http,$location){
	/*$scope.movieName='TOY';
    var url_default="http://www.omdbapi.com/?t="+$scope.movieName;
	$http.get(url_default).then(function(response){
			$scope.movieData=response.data;
	});*/
	$scope.findMovie=function(){
		movieName=$scope.movieName;
		var url="http://www.omdbapi.com/?t="+movieName;
		$http.get(url).then(function(response){
			alert("he");
			$scope.movieData=response.data;
			alert($scope.movieData.Title);
			
		});
		alert("sd");
		$location.url('pages/search.html');
	}
	
});